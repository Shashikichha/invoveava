import { useState } from 'react';
import './App.css';

function App() {

  let [state , setState] = useState(0);

  let getData = (event) =>{
    let num1 = Number(event.target.num1.value)
    let num2 = Number(event.target.num2.value)
    let sum = num1+num2
    const regx = /^[0-9\b]+$/;

    if(regx.test(num1) && regx.test(num2)){
      setState(sum)

      event.target.num1.value = ""
      event.target.num2.value = ""
    }

    event.preventDefault()
  }

  return (
    <>
    <h1>The Sum is {state}</h1>
      <form onSubmit={getData}>
        <div>
          <input type="text" name='num1' placeholder='Enter a number'/>
        </div>
        <div>
          <input type="text" name='num2' placeholder='Enter a number'/>
        </div>
        <div>
          <button type="submit">Add</button>
        </div>
      </form>
    </>
  );
}

export default App;
